# node_training_2022
Node JS Training 2022

## JOSH Training Routes / End-points
- `GET` `/` => homepage
  
### _Interns end-points_

- `GET` `/interns` => Get details of all the interns
- `GET` `/interns/new` => Page for adding a new intern
- `POST` `/interns/new` => Req for creating a new intern with all the required fileds
- `GET` `/interns/{id or name}` => Get details of a specific intern
- `PUT` `/interns/id` => Update `all details` of a specific intern
- `PATCH` `/interns/id` => Update `Subject` of a specific intern
- `DELETE` `/interns/id` => Delete a specific intern
  

### _Subjects end-points_

- `GET` `/subjects` => Get details of all the subjects
- `GET` `/subjects/new` => Page for adding a new subject
- `POST` `/subjects/new` => Req for creating a new subject with all the required fileds
- `GET` `/subjects/{sid or name}` => Get details of a specific subject
- `PUT` `/subjects/sid` => Update `all details` of a specific subject
- `PATCH` `/subjects/id` => Update `duration` of a specific subject
- `DELETE` `/subjects/id` => Delete a specific subject
  

### _Trainers end-points_

- `GET` `/trainers` => Get details of all the trainers
- `GET` `/trainers/new` => Page for adding a new trainer
- `POST` `/trainers/new` => Req for creating a new trainer with all the required fileds
- `GET` `/trainers/{tid or name}` => Get details of a specific trainer
- `PUT` `/trainers/id` => Update `all details` of a specific trainer
- `PATCH` `/trainers/id` => Update `Subject` of a specific trainer
- `DELETE` `/trainers/id` => Delete a specific trainer