require('dotenv').config({ path: './config/.env' });

const express = require('express');
const app = express();

const port = process.env.PORT;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const { pathLogger } = require('./middlewares/middlewares');
app.use(pathLogger);

const indexRouter = require('./routes');
const authRouter = require('./routes/authRouter');
const internsRouter = require('./routes/internsRouter');
const subjectsRouter = require('./routes/subjectsRouter');
const trainersRouter = require('./routes/trainersRouter');


app.use('/', indexRouter);
app.use('/', authRouter);
app.use('/interns', internsRouter);
app.use('/subjects', subjectsRouter);
app.use('/trainers', trainersRouter);



const server = app.listen(port);