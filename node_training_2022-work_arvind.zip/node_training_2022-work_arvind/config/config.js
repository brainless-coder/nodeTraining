require('dotenv').config(); 
const logger = require('../utils/logger');

module.exports = {
  "development": {
    "username": process.env.DB_USER,
    "password": process.env.DB_PASSWORD,
    "database": process.env.DB_NAME,
    // "username": "arvind",
    // "password": "hello@123",
    // "database": "node_training",
    "host": process.env.DB_HOST,
    "dialect": "mysql",
    "logging": msg => logger.info(msg),
  },
  "test": {
    "username": "root",
    "password": null,
    "database": "database_test",
    "host": "127.0.0.1",
    "dialect": "mysql"
  },
  "production": {
    "username": "root",
    "password": null,
    "database": "database_production",
    "host": "127.0.0.1",
    "dialect": "mysql"
  }
}
