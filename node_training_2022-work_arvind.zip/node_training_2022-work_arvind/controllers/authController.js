const authServices = require('../services/authServices');


const getLoginPage = (req, res) => {
  res.send('Login Page');
}

const postLogin = (req, res) => {
  const { username, password } = req.body;

  const response = authServices.postLoginService(username, password);
  res.json(response);
}


const postToken = (req, res) => {
  const refreshToken = req.body.token;
  const response = authServices.postTokenService(refreshToken);
  res.json(response);
}

const logout = (req, res) => {
  const token = req.body.token;
  const response = authServices.logoutService(token);
  res.sendStatus(response.status);
}


module.exports = {
  getLoginPage, postLogin, postToken, logout
}