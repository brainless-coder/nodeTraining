const internsServices = require('../services/internsServices');


const getAllInterns = async (req, res) => {
  const data = await internsServices.getAllInternsService();
  return res.status(200).json(data);
};

const getNewInternPage = (req, res) => {
  return res.render("interns/new");
};

const postNewInternPage = async (req, res) => {
  const { role } = req.user;
  const { name, subject, college, address } = req.body;
  const values = { name, subject, college, address };

  const data = await internsServices.postNewInternService(role, values);
  if (data == 403) {
    return res.sendStatus(403);
  }
  return res.status(201).json(data);
};

const getSpecIntern = async (req, res) => {
  const internID = req.params.internID;

  const data = await internsServices.getSpecInternService(internID);
  return res.json(data);
};

const putSpecIntern = async (req, res) => {
  const internID = req.params.internID;
  const { name, subject, college, address } = req.body;
  const values = { name, subject, college, address, internID };

  const data = await internsServices.putSpecInternService(values);
  return res.json(data);
};

const patchSpecIntern = async (req, res) => {
  const internID = req.params.internID;
  const values = { subject: req.body.subject, internID};
  
  const data = await internsServices.patchSpecInternService(values);
  return res.json(data);
};

const deleteSpecIntern = async (req, res) => {
  const internID = req.params.internID;
  
  const data = await internsServices.deleteSpecInternService(internID);
  return res.json(data);
};



module.exports = {
  getAllInterns,
  getNewInternPage,
  postNewInternPage,
  getSpecIntern,
  putSpecIntern,
  patchSpecIntern, 
  deleteSpecIntern
};
