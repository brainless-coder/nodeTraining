const { Interns } = require('../models');
const { Op } = require('sequelize');


exports.allInternsData = async () => {
  const interns = await Interns.findAll();
  return interns;
};

exports.createNewIntern = async (values) => {
  const intern = await Interns.create({
    name: values.name,
    subject: values.subject,
    college: values.college,
    address: values.address
  });
  
  return {
    affectedRows: 1,
    message: "Successfully inserted the record in interns table",
    intern,
  };
};

exports.specInternData = async (internID) => {
  const intern = await Interns.findAll({
     where: {  
      [Op.or]: [
        { id: internID },
        { name: internID },
      ] 
    } 
  });
  // Not working with name, the query is correct but not getting the result

  if (intern.length == 0) return {
    msg: "No Intern with this name or ID exists",
    sol: "make a GET req with correct ID or name"
  }

  return intern;
}

exports.updateIntern = async (values) => {
  const intern = await Interns.update({ 
    name: values.name, subject: values.subject, college: values.college, address: values.address
   }, { where: 
    { id: values.internID }
  });

  if (intern[0])  return "Intern Updated";
  return "Intern with this ID does not exist";  
}

exports.updateSubject = async (values) => {
  const intern = await Interns.update({ subject: values.subject }, {
    where: { id: values.internID}
  });
  
  if (intern[0])  return "Subject Updated";
  return "Intern with this ID does not exist";  
}

exports.deleteIntern = async (internID) => {
  const intern = await Interns.destroy({
    where: {
      id: internID
    }
  });
  
  if (intern)  return "Intern Deleted";
  return "Intern with this ID does not exist";  
}

