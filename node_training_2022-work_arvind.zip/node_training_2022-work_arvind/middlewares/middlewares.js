const logger = require('../utils/logger');

function pathLogger(req, res, next) {
    logger.info(`${req.method}  ${req.originalUrl}`);
    next();
}

const myMiddleWare = (options) => {
    return function (req, res, next) {
        console.log(options);
    }
}



module.exports = {
    pathLogger,  myMiddleWare
};