const { check, body, validationResult, matchedData} = require('express-validator')


const allFieldsSchema = [
    body('name').exists({ checkFalsy: true }).withMessage('name should be a string').trim().isLength({ min: 3 }).withMessage('min length should be 3'),
    body('subject').exists({ checkFalsy: true }).withMessage('subject should be a string').trim(),
    body('college').exists({ checkFalsy: true }).withMessage('college should be a string').trim(),
    body('address').exists({ checkFalsy: true }).withMessage('address should be a string').trim()
];

const idSchema = [ 
    check('internID', 'id shoudl be numeric').isNumeric()
];

const subjectSchema = [
    check('subject', 'subject should be a string').exists({ checkFalsy: true }).trim().blacklist(`<>'"/{}1234567890`), 
];


function validateIntern(req, res, next) {
    // console.log(matchedData(req));
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
}

module.exports = {
    allFieldsSchema, idSchema, subjectSchema, validateIntern
}