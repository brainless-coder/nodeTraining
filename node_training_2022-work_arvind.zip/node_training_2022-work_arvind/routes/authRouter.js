const express = require('express');
const router = express.Router();
const authenticateToken = require('../middlewares/jwtToken');
const authController = require('../controllers/authController');


// Login Route
router.get('/login', authController.getLoginPage);
router.post('/login', authController.postLogin);

// For creating our refresh tokens
router.post('/token', authenticateToken, authController.postToken);

// Invalidating our refresh token
router.delete('/logout', authenticateToken, authController.logout);


module.exports = router;