const express = require("express");
const router = express.Router();
const { allFieldsSchema, idSchema, subjectSchema, validateIntern } = require("../middlewares/validations/internsValidation");
const internsController = require("../controllers/internsController");
const authenticateToken = require('../middlewares/jwtToken');

// Route for getting all the interns
router.get("/", authenticateToken, internsController.getAllInterns);

// Route for adding a new intern
router.route("/new")
  .get(authenticateToken, internsController.getNewInternPage)
  .post(allFieldsSchema, validateIntern, authenticateToken, internsController.postNewInternPage);

// Route for a specific Intern
router.route("/:internID")
  .get(authenticateToken, internsController.getSpecIntern)
  .put(allFieldsSchema, idSchema, validateIntern, authenticateToken, internsController.putSpecIntern)
  .patch(subjectSchema, idSchema, validateIntern, authenticateToken, internsController.patchSpecIntern)
  .delete(idSchema, validateIntern, authenticateToken, internsController.deleteSpecIntern);


module.exports = router;