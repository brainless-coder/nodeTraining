const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    const query = 'select * from subjects';
    dbConnection.query(query, (err, result) => {
        if (err)  throw err;
        res.json(result);
    });
});

// Route for adding a new subject
router.route('/new')
    .get((req, res) => {
        res.json({
            route: "/subjects/new",
            desc: "page(form) for adding a new subject"
        });
    })
    .post((req, res) => {
        const { sid, name, duration, tid } = req.body;
        const query = 'insert into subjects values(?, ?, ?, ?)';
        const values = [sid, name, duration, tid];
        dbConnection.query(query, values, (err, result) => {
            if (err)  throw err;
            res.json(result);
        });
    });


// Route for a specific subject
router.route('/:subjectID')
    .get((req, res) => {
        const subjectID = req.params.subjectID;
        const query = 'select * from subjects where sid = ? OR name = ?';
        const values = [subjectID, subjectID];
        dbConnection.query(query, values, (err, result) => {
            if (err)  throw err;
            if (result.length === 0) {
                res.json({
                    msg: "No Subject with this id or name exisits",
                    sol: "make a GET req with the correct sid or name"
                });
            } else {
                res.json(result);
            }
        });
    })
    .put((req, res) => {
        const subjectID = req.params.subjectID;
        const { sid, name, duration, tid } = req.body;
        const query = 'update subjects set sid = ?, name = ?, duration = ?, tid = ? where sid = ?';
        const values = [sid, name, duration, tid, subjectID];
        dbConnection.query(query, values, (err, result) => {
            if (err)  throw err;
            res.json(result);
        });
    })
    .patch((req, res) => {
        const subjectID = req.params.subjectID;
        const query = 'update subjects set duration = ? where sid = ?';
        const values = [req.body.duration, subjectID];
        dbConnection.query(query, values, (err, result) => {
            if (err)  throw err;
            res.json(result);
        });
    })
    .delete((req, res) => {
        const subjectID = req.params.subjectID;
        const query = 'delete from subjects where sid = ?';
        const values = [subjectID];
        dbConnection.query(query, values, (err, result) => {
            if (err) throw err;
            res.json({
                status: "success",
                msg: `Deleted Subject with sid ${subjectID}`
            });
        });
    });




module.exports = router;