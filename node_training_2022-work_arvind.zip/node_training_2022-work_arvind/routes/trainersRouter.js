const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.json({
        route: "/trainers",
        desc: "GET details of all the Trainers"
    });
});

// Route for adding a new trainer
router.route('/new')
    .get((req, res) => {
        res.json({
            route: "/trainers/new",
            desc: "page(form) for adding a new trainer"
        });
    })
    .post((req, res) => {
        res.json({
            route: "/trainers/new",
            desc: "POST req for adding a new trainer"
        });
    });


// Route for a specific trainer
router.route('/:trainerID')
    .get((req, res) => {
        const trainerID = req.params.trainerID;
        res.json({
            route: `/trainers/${trainerID}`,
            desc: "GET details of a specific trainer"
        });
    })
    .put((req, res) => {
        const trainerID = req.params.trainerID;
        res.json({
            route: `/trainers/${trainerID}`,
            desc: "Update(PUT) details of a specific trainer"
        });
    })
    .patch((req, res) => {
        const trainerID = req.params.trainerID;
        res.json({
            route: `/trainers/${trainerID}`,
            desc: "Update(PATCH) details of a specific trainer"
        });
    })
    .delete((req, res) => {
        const trainerID = req.params.trainerID;
        res.json({
            route: `/trainers/${trainerID}`,
            desc: "Delete a specific trainer"
        });
    });




module.exports = router;