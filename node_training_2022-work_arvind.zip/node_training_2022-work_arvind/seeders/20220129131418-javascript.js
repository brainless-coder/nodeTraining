'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
    await queryInterface.bulkInsert('Interns', [
      {
        name: 'Arvind Prime',
        subject: 'Javascript',
        college: 'LNCT',
        address: 'Patil Nagar',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Shivprasad Vele',
        subject: 'Javascript',
        college: 'GWCD',
        address: 'Pashan',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: 'Sammed',
        subject: 'Javascript',
        college: 'LNCTE',
        address: 'Pashan Road',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Interns', {subject: 'Javascript'}, {});
  }
};
