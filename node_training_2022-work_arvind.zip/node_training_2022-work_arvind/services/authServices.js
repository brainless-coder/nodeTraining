const jwt = require('jsonwebtoken');
const users = require('./users');


let refreshTokens = [];


const postLoginService = (username, password) => {
  const currUser = users.find(user => user.username === username && user.password === password);

  if (currUser) {
    const user = { name: currUser.username, role: currUser.role };
    const accessToken  = generateAccessToken(user);
    const refreshToken = jwt.sign(user, process.env.REFRESH_TOKEN_SECRET);
    refreshTokens.push(refreshToken);
    return {accessToken, refreshToken};
  } else {
    return {
      msg: 'Username or password incorrect',
      sol: 'Retry with correct credentials'
    };
  }
}

const postTokenService = (refreshToken) => {
  if (refreshToken == null) return 401;
  if (!refreshTokens.includes(refreshToken))  return 403;

  jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
    if (err)  return 403;
    const accessToken = generateAccessToken({ name: user.name, role: user.role });
    return accessToken;
  });
}

const logoutService = (token) => {
  refreshTokens = refreshTokens.filter(t => t !== token);
  return { status: 204 };
}


// For generating a JWT
function generateAccessToken(user) {
  return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '1h' });
}




module.exports = {
  postLoginService, postTokenService, logoutService
}