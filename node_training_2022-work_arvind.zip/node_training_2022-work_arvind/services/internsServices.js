const internsHelper = require('../helpers/internsHelper');


exports.getAllInternsService = async () => {
  const data = await internsHelper.allInternsData();
  return data;
}

exports.postNewInternService = async (role, values) => {
  const data = await internsHelper.createNewIntern(values);
  return data;
};

exports.getSpecInternService = async (internID) => {
  const data = await internsHelper.specInternData(internID);
  return data;
};

exports.putSpecInternService = async (values) => {
  const data = await internsHelper.updateIntern(values);
  return data;
}

exports.patchSpecInternService = async (values) => {
  const data = await internsHelper.updateSubject(values);
  return data;
}

exports.deleteSpecInternService = async (internID) => {
  const data = await internsHelper.deleteIntern(internID);
  return data;
}