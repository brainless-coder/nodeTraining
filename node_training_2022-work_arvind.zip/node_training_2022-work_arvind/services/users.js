const users = [
    {
        username: 'saurabh',
        password: 'admin',
        role: 'admin'
    },
    {
        username: 'sunil',
        password: 'employee',
        role: 'employee'
    },
    {
        username: 'arvind',
        password: 'intern',
        role: 'intern'
    }
];

module.exports = users;