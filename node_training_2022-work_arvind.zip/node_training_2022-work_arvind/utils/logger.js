const { createLogger, format, transports } = require('winston');
const { timestamp, combine, printf, json } = format;
require("winston-daily-rotate-file");


// We can also create diff logs for diff services, like usersLog, authLog, etc

const logger = createLogger({
  defaultMeta: { role: 'intern' },
  format: combine(
    format.errors({stack: true})
  )
});

const logFormat = printf(({ level, message, timestamp, stack }) => {
  return `${timestamp} ${level}: ${stack || message}`;
});


if (process.env.NODE_ENV  === 'development') {
  logger.add(new transports.Console({
    format: combine(
      format.colorize(),
      format.simple(),
      timestamp({format: 'MMM-DD-YY HH:mm:ss'}),
      logFormat
    ),
  }));

} else {
  logger.add(new transports.File({
    filename: 'logs/errors.log',
    level: 'error',
    format: combine(
      format.errors({stack: true}),
      timestamp(),
      json(),
    )
  }));
  
  logger.add(new transports.File({
    filename: 'logs/combined.log',
    format: combine(
      format.errors({stack: true}),
      timestamp(),
      json(),
    )
  }));

  logger.add(new transports.DailyRotateFile({
    filename: 'logs/errors-%DATE%.log',
    datePattern: "YYYY-MM-DD",
    level: 'error',
    maxFiles: '14d',
    format: combine(
      format.errors({stack: true}),
      timestamp(),
      json()
    )
  }));
}


module.exports = logger;